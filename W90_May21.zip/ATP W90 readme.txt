PEW RESEARCH CENTER
Wave 90 American Trends Panel 
Dates: May 17-May 31, 2021
Mode: Web 
Sample: Subsample
Language: English and Spanish
N=2,548

***************************************************************************************************************************
NOTES

The sample for this survey was self-identified Twitter users from W85 (TWITTER1_W85=1).

For a small number of respondents with high risk of identification, certain values have been randomly swapped with those of lower risk cases with similar characteristics.


***************************************************************************************************************************
WEIGHTS 


WEIGHT_W90 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.


***************************************************************************************************************************
Releases from this survey:

November 15, 2021 "The Behaviors and Attitudes of U.S. Adults on Twitter"
https://www.pewresearch.org/internet/2021/11/15/the-behaviors-and-attitudes-of-u-s-adults-on-twitter/

November 15, 2021 "News on Twitter: Consumed by Most Users and Trusted by Many"
https://www.pewresearch.org/journalism/2021/11/15/news-on-twitter-consumed-by-most-users-and-trusted-by-many/

December 14, 2021 "How Americans tweet about the news"
https://www.pewresearch.org/fact-tank/2021/12/14/how-americans-tweet-about-the-news/

March 16, 2022 "5 facts about Twitter ‘lurkers’"
https://www.pewresearch.org/fact-tank/2022/03/16/5-facts-about-twitter-lurkers/

